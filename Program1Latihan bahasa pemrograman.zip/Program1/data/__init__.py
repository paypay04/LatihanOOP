# Import kelas-kelas yang akan digunakan dari modul data
from .mahasiswa import DataMahasiswa, Mahasiswa

__all__ = ["DataMahasiswa", "Mahasiswa"]
