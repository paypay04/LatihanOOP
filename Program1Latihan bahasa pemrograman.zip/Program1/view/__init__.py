# Import kelas-kelas yang akan digunakan dari modul view
from .input_form import InputForm
from .mahasiswa import MahasiswaView

__all__ = ["InputForm", "MahasiswaView"]
